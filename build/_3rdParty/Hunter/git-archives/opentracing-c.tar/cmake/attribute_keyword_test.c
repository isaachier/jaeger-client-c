ATTRIBUTE((unused)) void test(const char* str)
{
    (void) str;
}

int main(void)
{
    return 0;
}

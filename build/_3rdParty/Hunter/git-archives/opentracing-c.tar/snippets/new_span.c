#include "new_span.h"

#include "new_span_snippet.c"

#include "existing_span.h"
#include <string.h>

#include "existing_span_snippet.c"

#ifndef EXISTING_SPAN_H
#define EXISTING_SPAN_H

#include <opentracing-c/tracer.h>

void xyz(opentracing_span* parent_span);

#endif /* EXISTING_SPAN_H */

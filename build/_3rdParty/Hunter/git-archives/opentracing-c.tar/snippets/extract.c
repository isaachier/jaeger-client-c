#include "extract.h"

static void noop_destroy(opentracing_destructible* d) OPENTRACINGC_USED;

#include "extract_snippet.c"

#ifndef INJECT_H
#define INJECT_H

#include <opentracing-c/tracer.h>

void inject(void);

#endif /* INJECT_H */

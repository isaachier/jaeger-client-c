#include "inject.h"

#include <assert.h>
#include <stdio.h>

#include "text_map.h"

#include "inject_snippet.c"

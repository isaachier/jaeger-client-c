#ifndef NEW_SPAN_H
#define NEW_SPAN_H

#include <opentracing-c/tracer.h>

void abc(void);

#endif /* NEW_SPAN_H */
